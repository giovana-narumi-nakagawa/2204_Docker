# Sistema de Pesquisa de Satisfação - Ambiente Dockerizado

Este projeto configura um ambiente de desenvolvimento usando Docker para um sistema de pesquisa de satisfação de alunos.

## Como Executar

1. Clone o repositório:
   ```bash
   git clone https://github.com/giovana-narumi-nakagawa/Aula2204.git
   cd Aula2204